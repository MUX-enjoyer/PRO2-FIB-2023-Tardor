var indexSectionsWithContent =
{
  0: "abceimnpstv",
  1: "bce",
  2: "bcemp",
  3: "abceimnpstv",
  4: "bp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Pàgines"
};

