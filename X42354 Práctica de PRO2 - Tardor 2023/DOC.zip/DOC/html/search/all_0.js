var searchData=
[
  ['afegir_5fbici_0',['afegir_bici',['../class_estacion.html#a7049f08837d3a616ee7d2a5832d29059',1,'Estacion']]],
  ['alta_5fbici_1',['alta_bici',['../class_cjt___bicis.html#afb7f3ae78c0e2d47e03f0b4edb4c60d1',1,'Cjt_Bicis::alta_bici()'],['../class_cjt__estaciones.html#a4d502311fd6fa200b37e262aef0827f6',1,'Cjt_estaciones::alta_bici(string idBici, string idEstacion)']]],
  ['asignar_5festacion_2',['asignar_estacion',['../class_cjt__estaciones.html#a225709d9ae82f964373e9680e5cc56b5',1,'Cjt_estaciones']]]
];
