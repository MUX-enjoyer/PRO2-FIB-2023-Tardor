var searchData=
[
  ['plazas_5flibres_0',['plazas_libres',['../class_cjt__estaciones.html#aeeb4c00066bb9096272c0af8331f5bb5',1,'Cjt_estaciones']]]
];
