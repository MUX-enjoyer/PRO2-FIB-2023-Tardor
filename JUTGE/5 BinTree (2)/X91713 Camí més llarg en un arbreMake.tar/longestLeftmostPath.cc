#include "longestLeftmostPath.hh"

#include <list>

list<int> calc_cami_llarg(BinTree<int> t, int nivell) {
    list<int> cami_esq, cami_dreta;

    if (!t.left().empty()) cami_esq = calc_cami_llarg(t.left(), nivell+1);
    if (!t.right().empty()) cami_dreta = calc_cami_llarg(t.right(), nivell+1);

    if (cami_esq.size() < cami_dreta.size()) cami_esq = cami_dreta;
    cami_esq.push_front(t.value());
    return cami_esq;
}

// Pre:
// Post: Retorna la llista d'elements que es troben a t, baixant des de l'arrel i
//       seguint el camí més llarg. En cas de varis camins màxims,
//       escull el de més a l'esquerra.
list<int> longestLeftmostPath(BinTree<int> t) {
    list<int> cami_llarg;
    if (!t.empty()) cami_llarg = calc_cami_llarg(t, 0);
    return cami_llarg;
}