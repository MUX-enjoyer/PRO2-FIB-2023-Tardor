#include <iostream>
using namespace std;

#include "BinTree.hh"

// Pre: t és un BST
// Post: Retorna cert si i només si x apareix a t
bool searchInBST(BinTree<int> t, int x) {
    if (t.value() > x) return (!t.left().empty() && searchInBST(t.left(), x));
    else if (t.value() < x) return (!t.right().empty() && searchInBST(t.right(), x));
    else return (t.value() == x);
}