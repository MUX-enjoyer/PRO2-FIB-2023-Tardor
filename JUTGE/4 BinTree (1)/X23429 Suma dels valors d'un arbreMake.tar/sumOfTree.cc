#include <iostream>
using namespace std;

#include "BinTree.hh"

// Pre:
// Post: Retorna la suma dels valors de t
int sumOfTree(BinTree<int> t) {
    int suma = t.value();
    if (!t.right.empty()) suma += sumOfTree(t.right());
    if (!t.left.empty()) suma += sumOfTree(t.left());
    return suma;
}