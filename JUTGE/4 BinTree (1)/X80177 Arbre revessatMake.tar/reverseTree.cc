using namespace std;
#include <iostream>

#include "BinTree.hh"

BinTree<int> reverseTree(BinTree<int> t) {
    if (t.left().empty() && t.right().empty()) return t;

    BinTree<int> reversed = t;
    reversed.right() = reverseTree(t.left());
    reversed.left() = reverseTree(t.right());

    return reversed;
}