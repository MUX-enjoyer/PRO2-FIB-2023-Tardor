#include "maximumTree.hh"

BinTree<int> maximumTree(BinTree<int> a1, BinTree<int> a2) {
    if (a1.empty() && a2.empty()) return BinTree<int>();
    else if (a1.empty()) return a2;
    else if (a2.empty()) return a1;
    else {
        int valor;
        if (a1.value() > a2.value()) valor = a1.value();
        else valor = a2.value();
        BinTree<int> esq = maximumTree(a1.left(), a2.left());
        BinTree<int> dreta = maximumTree(a1.right(), a2.right());
        return BinTree<int> (valor, esq, dreta);
    }
}