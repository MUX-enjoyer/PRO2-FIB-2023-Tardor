#include <iostream>
#include <string>

using namespace std;

#include "utils.hh"

int evaluate(BinTree<string> t) {
    if (isNumber(t.value())) return mystoi(t.value());
    else {
        if (t.value() == '*') return t.right().value() * t.left().value();
        else if (t.value() == '+') return t.right().value() + t.left().value();
        else if (t.value() == '-') return t.right().value() - t.left().value();
    }
}